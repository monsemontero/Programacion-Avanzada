import java.util.concurrent.ThreadLocalRandom;
public class HiloGPS implements Runnable{
	
	public void run() {
		System.out.println(ThreadLocalRandom.current().nextInt());
			try{
				Thread.sleep(1000); 
			}catch(InterruptedException e) {
				e.printStackTrace();
			}  
	}
	
}

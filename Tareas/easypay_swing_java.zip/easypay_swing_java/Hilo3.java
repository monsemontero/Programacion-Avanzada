public class Hilo3 implements Runnable{
	private EasyPay principal;
	
	public Hilo3(EasyPay principal) {
		this.principal = principal;
	}
	
	public void run() {
		principal.modelo3.clear();
		int contador = 0;
		for (int i=0 ; i<=100; i++){
			if(i % 15 == 0)
				principal.modelo3.addElement("cargando " + i +"%");
				contador++;
				try{
					Thread.sleep(1000, 500); 
				}catch(InterruptedException e) {
					e.printStackTrace();
				}  
        }
	}
}
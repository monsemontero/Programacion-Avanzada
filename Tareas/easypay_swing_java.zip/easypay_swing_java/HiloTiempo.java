import java.util.concurrent.ThreadLocalRandom;
public class HiloTiempo implements Runnable{

	public void run() {
		
			try{
				System.out.println(ThreadLocalRandom.current().nextInt(10));
				Thread.sleep(1000); 
			}catch(InterruptedException e) {
				e.printStackTrace();
			}  
        
	}
}

/**
 * Implementación del AbstractListModel para Jlist más completos
 */

package adaptadores;
import model.*;
import javax.swing.*;
import java.util.*;
import java.util.Arrays;
import java.util.List;

public class MiListModelPagos extends AbstractListModel<Pago> {

    private static final long serialVersionUID = 40L;
    ArrayList<Pago> list=new ArrayList<>();

    public MiListModelPagos(List<Pago> pagos) {
      list = new ArrayList<Pago>(pagos);
    }

    public int getSize() {
      return list.size();
    }

    public Pago getElementAt(int index) {
      return list.get(index);
    }

    // if you need such updates:
    public void add(int index, Pago item) {
      list.add(index, item);
      fireIntervalAdded(this, index, index);
    }

    public boolean remove(Pago i) {
      int index = list.indexOf(i);
      if(index<0) return false;
      remove(index);
      return true;
    }

    public void remove(int index) {
      list.remove(index);
      fireIntervalRemoved(this, index, index);
    }
}
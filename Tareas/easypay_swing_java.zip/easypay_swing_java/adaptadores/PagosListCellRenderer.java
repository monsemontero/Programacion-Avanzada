/** 
 * Adaptador para el Jlist
 */
package adaptadores;

import javax.swing.DefaultListCellRenderer;
import java.awt.*;
import javax.swing.*;
import model.*;

public class PagosListCellRenderer extends DefaultListCellRenderer {

    private static final long serialVersionUID = 60L;


    public Component getListCellRendererComponent(JList<?> list,
                                 Object value,
                                 int index,
                                 boolean isSelected,
                                 boolean cellHasFocus) {
        super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
        if (value instanceof Pago) {
            Pago pago = (Pago)value;

            setText(pago.getID() + " - " + pago.getFecha() + " < Recibo ID: " + Integer.toString(pago.getRecibo().getID()) + ", " +  pago.getRecibo().getPeriodo() + ">< $" + Float.toString(pago.getRecibo().getMonto())  + "  MXN> " + "<" + pago.getRecibo().getUsuario().getNombreCompleto() + ">"  );
            setToolTipText(pago.getRecibo().getUsuario().getNombreCompleto());
        }
        return this;
    }
}
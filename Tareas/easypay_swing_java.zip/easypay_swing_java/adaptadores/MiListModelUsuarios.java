/**
 * Implementación del AbstractListModel para Jlist más completos
 */

package adaptadores;
import model.*;
import javax.swing.*;
import java.util.*;
import java.util.Arrays;
import java.util.List;

public class MiListModelUsuarios extends AbstractListModel<Usuario> {

    private static final long serialVersionUID = 40L;
    ArrayList<Usuario> list=new ArrayList<>();

    public MiListModelUsuarios(List<Usuario> usuarios) {
      list = new ArrayList<Usuario>(usuarios);
    }

    public int getSize() {
      return list.size();
    }

    public Usuario getElementAt(int index) {
      return list.get(index);
    }

    // if you need such updates:
    public void add(int index, Usuario item) {
      list.add(index, item);
      fireIntervalAdded(this, index, index);
    }

    public boolean remove(Usuario i) {
      int index = list.indexOf(i);
      if(index<0) return false;
      remove(index);
      return true;
    }

    public void remove(int index) {
      list.remove(index);
      fireIntervalRemoved(this, index, index);
    }
}
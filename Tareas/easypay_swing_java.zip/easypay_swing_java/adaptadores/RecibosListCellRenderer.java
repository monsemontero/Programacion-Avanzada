/** 
 * Adaptador para el Jlist
 */
package adaptadores;

import javax.swing.DefaultListCellRenderer;
import java.awt.*;
import javax.swing.*;
import model.*;

public class RecibosListCellRenderer extends DefaultListCellRenderer {

    private static final long serialVersionUID = 50L;


    public Component getListCellRendererComponent(JList<?> list,
                                 Object value,
                                 int index,
                                 boolean isSelected,
                                 boolean cellHasFocus) {
        super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
        if (value instanceof Recibo) {
            Recibo recibo = (Recibo)value;

            setText(recibo.getID() + " - " + recibo.getPeriodo() + " <$" + Float.toString(recibo.getMonto()) + " MXN> " + "<" + recibo.getUsuario().getNombreCompleto() + ">"  );
            setToolTipText(recibo.getPeriodo());
        }
        return this;
    }
}
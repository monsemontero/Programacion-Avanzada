/** 
 * Adaptador para el Jlist
 */
package adaptadores;

import javax.swing.DefaultListCellRenderer;
import java.awt.*;
import javax.swing.*;
import model.*;

public class UsuariosListCellRenderer extends DefaultListCellRenderer {

    private static final long serialVersionUID = 50L;


    public Component getListCellRendererComponent(JList<?> list,
                                 Object value,
                                 int index,
                                 boolean isSelected,
                                 boolean cellHasFocus) {
        super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
        if (value instanceof Usuario) {
            Usuario usuario = (Usuario)value;
            setText(usuario.getNombre() + " " + usuario.getApellidos() + " <" + usuario.getEmail() + ">");
            setToolTipText(usuario.getEmail());
        }
        return this;
    }
}
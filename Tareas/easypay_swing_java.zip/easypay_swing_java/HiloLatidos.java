import java.util.concurrent.ThreadLocalRandom;
public class HiloLatidos implements Runnable{
	
	public void run() {
		 System.out.println(ThreadLocalRandom.current().nextInt(50, 200));
				try{
					Thread.sleep(1000); 
				}catch(InterruptedException e) {
					e.printStackTrace();
				}  
        
	}
}


public class Hilo1 implements Runnable{
	private EasyPay principal;
	
	public Hilo1(EasyPay principal) {
		this.principal = principal;
	}
	
	public void run() {
		principal.modelo1.clear();
		int contador = 0;
		for (int i=0 ; i<=100; i++){
			if(i % 20 == 0)
				principal.modelo1.addElement("cargando " + i +"%");
				contador++;
				try{
					Thread.sleep(1000); 
				}catch(InterruptedException e) {
					e.printStackTrace();
				}  
        }
	}
}

import javax.swing.*;

public class Hilo implements Runnable {
	private JDesktopPane pane;
	private long tiempo;
	private int salto;
	private DefaultListModel<String> modelo;
	Hilo(JDesktopPane pane,long tiempo, int salto){
		this.pane=pane;
		this.tiempo=tiempo;
		this.salto=salto;
		
		JInternalFrame ventana = new JInternalFrame ("Ventana",true,true,true,true);
		ventana.setSize(200, 200);
		
		modelo= new DefaultListModel<String>();
		JList<String> lista = new JList<String>(modelo);
		
		JScrollPane scroll = new JScrollPane(lista);
		ventana.add(scroll);	
		pane.add(ventana);
		ventana.setVisible(true);
	}
	public Hilo(EasyPay contexto) {
		// TODO Auto-generated constructor stub
	}
	public void run () {
		for (int contador=0; contador<=100; contador=contador+salto) {
			modelo.addElement("Elemento "+contador);
			try{
				Thread.sleep(tiempo); 
			}catch(InterruptedException e) {
				e.printStackTrace();
			} 
		}
	}
	
}
public class Hilo2 implements Runnable{
	private EasyPay principal;
	
	public Hilo2(EasyPay principal) {
		this.principal = principal;
	}
	
	public void run() {
		principal.modelo2.clear();
		int contador = 0;
		for (int i=0 ; i<=100; i++){
			if(i % 10 == 0)
				principal.modelo2.addElement("cargando " + i +"%");
				contador++;
				try{
					Thread.sleep(700); 
				}catch(InterruptedException e) {
					e.printStackTrace();
				}  
        }
	}
}
/**
 * Clase Recibo
 */

package model;

public class Recibo {


    private int ID;
    private Usuario Usuario;
    private String Periodo;
    private float Monto;

     // Constructor con parámetros
     public Recibo(int ID, Usuario Usuario, String Periodo, float Monto) {
        this.ID = ID;
        this.Usuario = Usuario;
        this.Periodo = Periodo;
        this.Monto = Monto;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public int getID() {
        return ID;
    }

    public void setUsuario(Usuario Usuario) {
        this.Usuario = Usuario;
    }

    public Usuario getUsuario() {
        return Usuario;
    }

    public void setPeriodo(String Periodo) {
        this.Periodo = Periodo;
    }

    public String getPeriodo() {
        return Periodo;
    }

    public void setMonto(float Monto) {
        this.Monto = Monto;
    }

    public float getMonto() {
        return Monto;
    }
   


} 

/**
 * Clase Datos
 * Esta clase contiene los datos de prueba de la aplicación
 */
package model;
import java.util.*;
import java.util.Arrays;
import java.util.List;

import model.Usuario;
public class Datos
{


    public  List<Usuario> usuarios;
    public  List<Recibo> recibos;
    public  List<Pago> pagos;

    public  Datos()
    {
        usuarios = new ArrayList<Usuario>();
        recibos = new ArrayList<Recibo>();
        pagos = new ArrayList<Pago>();

        Usuario usuario1 = new Usuario(1, "Vlad", "Drăculea", "alucard@gmail.com", "1234");
        Usuario usuario2 = new Usuario(2, "Dorian", "Gray", "eternalLife@gmail.com", "1468");
        Usuario usuario3 = new Usuario(3, "Jeanne", "d'Arc", "DoncelladeOrleans@gmail.com", "1689");


        // Datos de prueba del usuario
        usuarios.add(usuario1);
        usuarios.add(usuario2);
        usuarios.add(usuario3);

        // Datos de prueba de los recibos

        Recibo recibo1 = new Recibo(1, usuario1, "Enero-febrero 2018", 500f);
        Recibo recibo2 = new Recibo(2, usuario1, "Febrero-marzo 2018", 125.00f);
        Recibo recibo3 = new Recibo(3, usuario1, "Marzo-abril 2018", 345.32f);
        Recibo recibo4 = new Recibo(4, usuario2, "Enero-febrero 2018", 400f);
        Recibo recibo5 = new Recibo(5, usuario2, "Febrero-marzo 2018", 725.00f);
        Recibo recibo6 = new Recibo(6, usuario2, "Marzo-abril 2018", 1345.32f);
        Recibo recibo7 = new Recibo(7, usuario3, "Enero-febrero 2018", 134f);
        Recibo recibo8 = new Recibo(8, usuario3, "Febrero-marzo 2018", 378.00f);
        Recibo recibo9 = new Recibo(9, usuario3, "Marzo-abril 2018", 69.32f);

        recibos.add(recibo1);
        recibos.add(recibo2);
        recibos.add(recibo3);
        recibos.add(recibo4);
        recibos.add(recibo5);
        recibos.add(recibo6);
        recibos.add(recibo7);
        recibos.add(recibo8);
        recibos.add(recibo9);

        // Datos de prueba de los pagos
        pagos.add(new Pago(1,recibo2,"Marzo 12, 2018 13:00:00"));
        pagos.add(new Pago(2,recibo5,"Marzo 14, 2018 17:52:00"));
        pagos.add(new Pago(3,recibo7,"Febreri 9, 2018 03:00:00"));


    }

}
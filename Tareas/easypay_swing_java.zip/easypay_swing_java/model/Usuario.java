/**
 * Clase Usuario
 */

package model;

public class Usuario {

    private int ID;
    private String Nombre;
    private String Apellidos;
    private String Email;
    private String Password;

    // Constructor vacío
    public Usuario() {

    }

    // Constructor con parámetros
    public Usuario(int ID, String Nombre, String Apellidos, String Email, String Password) {
        this.ID = ID;
        this.Nombre = Nombre;
        this.Apellidos = Apellidos;
        this.Email = Email;
        this.Password = Password;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public int getID() {
        return ID;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setApellidos(String Apellidos) {
        this.Apellidos = Apellidos;
    }

    public String getApellidos() {
        return Apellidos;
    }

    public void setEmail(String Email) {
        this.Email = Email;
    }

    public String getEmail() {
        return Email;
    }

    public void setPassword(String Password) {
        this.Password = Password;
    }

    public String getPassword() {
        return Password;
    }

    public String getNombreCompleto() {
        return Nombre + " " + Apellidos;
    }

} 

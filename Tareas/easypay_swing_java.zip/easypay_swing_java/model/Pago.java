/**
 * Clase Pagos
 */

package model;

public class Pago {


    private int ID;
    private Recibo Recibo;
    private String Fecha;

     // Constructor con parámetros
     public Pago(int ID, Recibo Recibo, String Fecha) {
        this.ID = ID;
        this.Recibo = Recibo;
        this.Fecha = Fecha;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public int getID() {
        return ID;
    }

    public void setRecibo(Recibo Recibo) {
        this.Recibo = Recibo;
    }

    public Recibo getRecibo() {
        return Recibo;
    }


    public void setFecha(String Fecha) {
        this.Fecha = Fecha;
    }

    public String getFecha() {
        return Fecha;
    }

   

} 
